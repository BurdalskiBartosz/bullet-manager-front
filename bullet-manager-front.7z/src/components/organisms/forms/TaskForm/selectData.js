export const prioritySelectValues = [
	{
		key: '1',
		value: '1'
	},
	{
		key: '2',
		value: '2'
	},
	{
		key: '3',
		value: '3'
	}
];
export const typeSelectValues = [
	{
		key: 'DAILY',
		value: 'Dzienne'
	},
	{
		key: 'WEEKLY',
		value: 'Tygodniowe'
	},
	{
		key: 'MONTHLY',
		value: 'Miesięczne'
	}
];
