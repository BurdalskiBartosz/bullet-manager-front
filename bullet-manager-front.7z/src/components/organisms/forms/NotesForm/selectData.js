export const typeNoteSelectValues = [
	{
		key: 'primary',
		value: 'Domyślny'
	},
	{
		key: 'secondary',
		value: 'Inny rodzaj'
	},
	{
		key: 'tetiary',
		value: 'Trzeci rodzaj'
	}
];
