import { format } from 'date-fns';

export const dateFormat = (value) => format(value, 'MM/dd/yyyy');
