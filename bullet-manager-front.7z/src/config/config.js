export const config = {
	baseUrl: 'http://localhost:3001/api'
};
